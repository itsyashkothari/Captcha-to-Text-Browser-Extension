/*
Just draw a border round the document.body.
*/
function UserAction(imgData) {
    var t = document.body.getElementsByTagName("input")[0]
    var l;
    var data = { "name": "John Doe", "age": "21", "extra": imgData };
    var url = 'https://6dc3f6f1.ngrok.io/predict23';
    console.log(data.imgData);
    fetch(url, {
            method: 'POST', 
            body: JSON.stringify(data),
            headers: new Headers({
                'Content-Type': 'application/json'
            })
        }).then(res => res.json())
        .then(function(response){  console.log(response.value);
            l = response.value;
            document.body.getElementsByTagName("input")[0].value = l;
        })
    // document.body.getElementsByTagName("input")[0].value = "response.value" 

console.log(t);
}

function getBase64Image(img) {
    var canvas = document.createElement("canvas");
    canvas.width = img.width;
    canvas.height = img.height;

    var ctx = canvas.getContext("2d");
    ctx.drawImage(img, 0, 0);

    var dataURL = canvas.toDataURL("image/png");

    return dataURL.replace(/^data:image\/(png|jpg);base64,/, "");
}
setTimeout(hola, 3000)



function hola() {

    var image = document.body.getElementsByTagName("img");
    var imgData = getBase64Image(image[1]);
    document.body.style.border = "5px solid red";
    UserAction(imgData);

}